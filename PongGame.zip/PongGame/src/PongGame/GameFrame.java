package PongGame;

import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;
import java.awt.Color;
import javax.swing.JFrame;


public class GameFrame extends JFrame{
	
	private static final long serialVersionUID = 1L;
    private AI ai;
    private Paddle human;
    private Ball ball;
    private GamePanel panel;

    public GameFrame() {
        initializeGameComponents();
        setupUI();
        
    }

    private void initializeGameComponents() {
        ball = new Ball(50, 50, 20, 20);  //50,50,10,25
        ai = new AI(1350, GamePanel.GAME_HEIGHT / 2 - AI.PADDLE_HEIGHT / 2, 150, AI.PADDLE_HEIGHT, ball);
        
        human = new Paddle(50, GamePanel.GAME_HEIGHT / 2 - Paddle.PADDLE_HEIGHT / 2, 20, Paddle.PADDLE_HEIGHT, 1, ball);
        panel = new GamePanel(ai, human, ball);

        // Call initializeBallDirection to set the initial ball direction
        ball.initializeBallDirection();
        
    }

    private void setupUI() {
        setTitle("Pong!!!");
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        add(panel);
        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new GameFrame();
        });
    }
}
	

	/*
	GameFrame(){
		//panel = new GamePanel(ball, ai, human);
		
		ball = new Ball(50, 50, 10, 25);
		ai = new AI(1350, 1250, 150, 50, ball);
		human = new Paddle(50, 20, 20, 50, 1, ball);
		panel = new GamePanel(ai, human, ball);
		this.add(panel);
		this.setTitle("Pong!!!"); 
		this.setResizable(false); 
		//panel.setBackground(Color.white); 
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setVisible(true); 
		this.pack();
		this.setLocationRelativeTo(null); 
		
	}*/



