/**
 * 
 */
/**
 * @author youkh
 *
 */
module PongGame {
	requires java.desktop;
}